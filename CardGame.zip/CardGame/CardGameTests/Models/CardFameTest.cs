﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CardGame.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace CardGame.Models.Tests
{
    [TestClass()]
    public class CardFameTest
    {
        // Check on the shuffle of cards
        [TestMethod()]
        public void deckShuffleTest()
        {
            Deck testDeck = new Deck(1);
            List<Card> cardInDeckBeforeShuffle = Helper.Clone(testDeck.cards);
            testDeck.ShuffleDeck();                        

            // Check if the sequence of cards is equal or not  before shuffle and after shuffle
            bool isSequenceEqualAfterShuffle = testDeck.cards.SequenceEqual(cardInDeckBeforeShuffle);
            Assert.IsFalse(isSequenceEqualAfterShuffle);

            /* to be examined */
           // bool isTestDeckHavingSameCardsAfterShuffle = new HashSet<Card>(cardInDeckBeforeShuffle).SetEquals(testDeck.cards);
           // Assert.IsTrue(isTestDeckHavingSameCardsAfterShuffle);
        }


        // check if players cards in draw pile is reduced properly on each round 
        [TestMethod()]
        public void playerCardDrawFromNonEmptyDrawPileTest()
        {
            Player testPlayer = new Player("TestPlayer");
            testPlayer.drawPile = new Deck(1);
            testPlayer.discardPile = new Deck(0);

            // count of player drawPile decreases by 1 on each drawTopCard() call.
            testPlayer.drawPile.drawTopCard();
            Assert.AreEqual(testPlayer.drawPile.getCardCount(), new Deck(1).getCardCount() - 1);
            testPlayer.drawPile.drawTopCard();
            Assert.AreEqual(testPlayer.drawPile.getCardCount(), new Deck(1).getCardCount() - 2);
            testPlayer.drawPile.drawTopCard();
            Assert.AreEqual(testPlayer.drawPile.getCardCount(), new Deck(1).getCardCount() - 3);
        }


        // check if player's cards in draw pile is automatically fetched from discard pile 
        // when the draw pile is empty
        [TestMethod()]
        public void playerCardDrawFromEmptyDrawPileTest()
        {
            Player testPlayer = new Player("TestPlayer");
            testPlayer.drawPile = new Deck(0);
            testPlayer.discardPile = new Deck(1);
          
            // Check drawPile and DiscardPile after filling empty drawPile with discardPile
            int initialDiscardPileCount = testPlayer.discardPile.getCardCount();
            testPlayer.fillDrawPileFromDiscard();
            int afterDrawPileCount = testPlayer.drawPile.getCardCount();
            int afterDiscardPileCount = testPlayer.discardPile.getCardCount();

            Assert.AreEqual(initialDiscardPileCount, afterDrawPileCount);   // draw pile should have all cards of discarp pile
            Assert.AreEqual(0, afterDiscardPileCount);  // discard pile should be empty
        }


        // chekc if cards count of a player is adjusted properly
        // after player draws the card
        [TestMethod()]
        public void deckLengthAfterDrawTest()
        {
            Game testGame = new Game(2, 1);
            int initialPlayer1CardsCount = testGame.players[0].getPlayerTotalCardsCount();
            testGame.players[0].drawPile.drawTopCard();
            int afterDrawPlayer1CardsCount = testGame.players[0].getPlayerTotalCardsCount();
            Assert.AreEqual(1, initialPlayer1CardsCount - afterDrawPlayer1CardsCount);
        }

        // A new deck should contain 40 cards
        // each player should have equal cards in hand before game starts
        [TestMethod()]
        public void cardsInANewdeckCountTest()
        {
            Game testGame = new Game(2, 1);
            int initialPlayer1CardsCount = testGame.players[0].getPlayerTotalCardsCount();
            int initialPlayer2CardsCount = testGame.players[1].getPlayerTotalCardsCount();           
            Assert.AreEqual(40, initialPlayer1CardsCount + initialPlayer2CardsCount);
            Assert.AreEqual(initialPlayer1CardsCount, initialPlayer2CardsCount);
        }

        // check if player with highest card value wins the round
        [TestMethod()]
        public void correctPlayerWinsTest()
        {
            Game testGame = new Game(2, 1);
            // keep only 2 cards in game and asign those 2 cards to each player.
            Card testCard1 = new Card(Suit.Club, CardRank.Five);
            Card testCard2 = new Card(Suit.Diamond, CardRank.One);           
            testGame.players[0].drawPile.removeAllFromDeck();
            testGame.players[0].drawPile.addCardToDeck(testCard1);
            testGame.players[1].drawPile.removeAllFromDeck();
            testGame.players[1].drawPile.addCardToDeck(testCard2);
            testGame.BeginGame();
            // player[0] is asigned card of rank 5, which is greater that player[1].
            // so player[0] should win the game
            Assert.AreEqual(testGame.winningPlayer.name, testGame.players[0].name);
        }
    }
}