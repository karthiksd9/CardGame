﻿// -----------------------------------------------------------------------------
// <copyright file="Program.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame
{
    using System;
    using CardGame.Models;
    class Program
    {
        // Modify below parameter to change the number of players playing the game
        public static readonly int initialNumberOfPlayers = 2;
        // Modify below parameter to change the number decks to be used in game
        public static readonly int initialNoOfDecks = 1;

        static void Main(string[] args)
        {
            Game game = new Game(initialNumberOfPlayers, initialNoOfDecks);
            game.BeginGame();
            Console.WriteLine($"WINNER OF CARDS GAME : {game.winningPlayer.name}");
            Console.ReadKey();
        }
    }
}
    
