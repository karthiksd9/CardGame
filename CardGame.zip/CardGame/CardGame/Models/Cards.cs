﻿// -----------------------------------------------------------------------------
// <copyright file="Cards.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame.Models
{
    public enum Suit
    {
        Club,
        Diamond,
        Spade,
        Heart
    }

    public enum CardRank
    {
        One,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten
    }

  
    public class Card
    {
        /// <summary>
        /// Suit value of a card.
        /// </summary>
        public Suit Suit { get; set; }

        /// <summary>
        /// Rank of a card(1 - 10).
        /// </summary>
        public CardRank Value { get; set; }

        /// <summary> Initializes the card </summary>
        public Card(Suit suit, CardRank rank)
        {
            this.Suit = suit;
            this.Value = rank;
        }

        /// <summary>
        /// Print the card value of a suit 
        /// </summary>
        /// <returns>Card value in a readable format</returns>
        public override string ToString()
        {
            return $"The { Value } of { Suit }";
        }
    }
}
