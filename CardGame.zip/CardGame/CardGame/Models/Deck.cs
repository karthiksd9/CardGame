﻿// -----------------------------------------------------------------------------
// <copyright file="Deck.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame.Models
{
    using System;
    using System.Collections.Generic;

    public class Deck
    {
        /// <summary>
        /// list of cards available in the deck.
        /// </summary>
        public List<Card> cards = new List<Card>();

        /// <summary>Fill the deck with cards by combining Suit and CardRank values</summary>
        /// <param name="deckSize">No of decks available for filling cards.(1 deck = 10 cards)</param>
        public Deck(int deckSize)
        {
            while (deckSize > 0)
            {
                // Creation of each card suite deck chunk
                for (int j = 0; j < Enum.GetNames(typeof(Suit)).Length; j++)
                {
                    // Creation of the individual card
                    for (int i = 0; i < Enum.GetNames(typeof(CardRank)).Length; i++)
                    {
                        cards.Add(new Card((Suit)j, (CardRank)i));
                    }
                }
                deckSize--;
            }
        }

        /// <summary> add a card into the cards list in the deck </summary>
        /// <param name="card">card that is to be added into deck card list</param>
        public void addCardToDeck(Card card)
        {
            cards.Add(card);
        }

        /// <summary> Removes all the cards from the deck </summary>
        public void removeAllFromDeck()
        {
            cards.Clear();
        }

        /// <summary> pick the card from the top  of the deck and return it </summary>
        /// <returns>Card from top of the deck card list</returns>
        public Card drawTopCard()
        {
            Card card = null;
            if (!isEmpty())
            {
                card = cards[cards.Count - 1];
                cards.RemoveAt(cards.Count - 1);
            }                
            else
                card = null;

            return card;
        }

        /// <summary> Check if deck has any cards on it or not</summary>
        /// <returns>True if deck is empty, False otherwise</returns>
        public bool isEmpty()
        {
            return (cards.Count <= 0);
        }

        /// <summary> To gethe the no of cards available in deck</summary>
        /// <returns>count of cards in deck</returns>
        public int getCardCount()
        {
            return cards.Count;
        }

        /// <summary> 
        /// Shuffle the cards available in deck
        /// It internally calls FisherYates shuffle method
        /// </summary>
        public void ShuffleDeck()
        {
            FisherYatesShuffle.Shuffle(cards);            
        }
    }
}
