﻿// -----------------------------------------------------------------------------
// <copyright file="Helper.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame.Models
{
    using Newtonsoft.Json;

    public static class Helper
    {
        /// <summary>
        /// store the object into secondary memory location and return it
        /// <param name="source"> source object of any type of which data should be copied </param>
        /// <returns> copied object of source </returns>
        /// </summary>
        public static T Clone<T>(T source)
        {
            var serialized = JsonConvert.SerializeObject(source);
            return JsonConvert.DeserializeObject<T>(serialized);
        }
    }
}
