﻿// -----------------------------------------------------------------------------
// <copyright file="Game.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Game
    {
        /// <summary>
        /// initial set of players at the start of the game
        /// </summary>
        public Player[] players { get; set; }

        /// <summary>
        /// deck that holds the cards of players drawn card on each round
        /// </summary>
        public Deck gameDeck { get; set; }

        /// <summary>
        /// deck that holds the cards when the round is draw between players
        /// </summary>
        public Deck drawDeck { get; set; }

        /// <summary>
        /// remaining players left in the game
        /// </summary>
        public int remainingPlayersinGame { set; get; }

        /// <summary>
        /// Winning player of the cards game
        /// </summary>
        public Player winningPlayer { get; set; }

        /// <summary>
        /// Initializes the game
        /// creates the players, shuffles the deck and 
        /// distrubute the deck cards among the players
        /// <param name="NoOfplayers">number of players who play the game</param>
        /// <param name="noOfDecks">number of decks available to play the game</param>
        /// </summary>
        public Game(int NoOfplayers, int noOfDecks)
        {
            remainingPlayersinGame = NoOfplayers;
            players = new Player[NoOfplayers];

            // initialize players with default player name
            for (int i = 0; i < remainingPlayersinGame; i++)
            {
                players[i] = new Player($"Player-{ i + 1 }");
            }

            this.gameDeck = new Deck(0);
            this.drawDeck = new Deck(0);

            Deck deck = new Deck(noOfDecks);
            deck.ShuffleDeck();
            initializePlayersCards(deck);
        }


        /// <summary>
        /// Starts the game
        /// each player draws their top cards
        /// players are elimated once their cards are empty
        /// last remaining player is set as Winning player
        /// </summary>
        public void BeginGame()
        {
            while (remainingPlayersinGame > 1)
            {
                for (int iPlayerIdx = 0; iPlayerIdx < remainingPlayersinGame; iPlayerIdx++)
                {
                    Card drawCard = players[iPlayerIdx].drawPile.drawTopCard();
                    if (drawCard != null)
                    {
                        Console.WriteLine($"{players[iPlayerIdx].name } ({players[iPlayerIdx].getPlayerTotalCardsCount()} Cards) : {drawCard.ToString()}");
                        gameDeck.addCardToDeck(drawCard);
                    }
                    else
                    {
                        Console.WriteLine($"Draw pile of {players[iPlayerIdx].name} is empty. Checking discarded pile");
                        players[iPlayerIdx].fillDrawPileFromDiscard();

                        if (players[iPlayerIdx].drawPile.isEmpty())
                        {
                            Console.WriteLine($"{players[iPlayerIdx].name} has 0 cards left. Exiting from game");

                            var updatedPlayersList = new List<Player>(players);
                            updatedPlayersList.RemoveAt(iPlayerIdx);
                            players = updatedPlayersList.ToArray();
                            remainingPlayersinGame--;
                        }
                        else
                        {
                            drawCard = players[iPlayerIdx].drawPile.drawTopCard();
                            Console.WriteLine($"{players[iPlayerIdx].name } ({players[iPlayerIdx].getPlayerTotalCardsCount()} Cards) : {drawCard.ToString()}");
                            gameDeck.addCardToDeck(drawCard);
                        }
                    }
                }


                int maxIdx = compareCardsOfGameDeck(gameDeck);
                if (maxIdx > -1)
                {
                    foreach (Card card in gameDeck.cards)
                        players[maxIdx].discardPile.addCardToDeck(card);

                    if (!drawDeck.isEmpty())
                    {
                        foreach (Card card in drawDeck.cards)
                            players[maxIdx].discardPile.addCardToDeck(card);
                        drawDeck.removeAllFromDeck();
                    }
                    Console.WriteLine($"{players[maxIdx].name} wins this round");
                }
                else
                {
                    Console.WriteLine("No winner in this round!");

                    foreach (Card card in gameDeck.cards)
                        drawDeck.addCardToDeck(card);
                }

                gameDeck.removeAllFromDeck();

                Console.WriteLine();
            }

            winningPlayer = players[0];            
        }


        /// <summary>
        /// Distributes the shuffeled cards in the deck among all the players
        /// Cards are equally distributed among players
        /// if any additional cards is remained after equally distributed, those cards are discarded from the game
        /// <param name="deck">Deck from where cards are distributed among players</param>
        /// </summary>
        private void initializePlayersCards(Deck deck)
        {
            int remainingCards = deck.getCardCount() % players.Length;

            if (remainingCards > 0)
            {
                Console.WriteLine($"{deck.getCardCount()} cards cannot be equally distributed among {players.Length} players. Dropping {remainingCards} cards from deck");
                while (remainingCards > 0)
                {
                    deck.drawTopCard();
                    remainingCards--;
                }
            }

            for (int i = 0; i < deck.getCardCount(); i += players.Length)
            {
                int count = players.Length;
                int c = i;
                while (count > 0)
                {
                    players[count - 1].drawPile.cards.Add(deck.cards[c++]);
                    count--;
                }
            }
        }

        /// <summary>
        /// finds the index of the card which has highest value 
        /// <param name="deck">game deck on which players draws their top card</param>
        /// <returns>index of the max value card</returns>
        /// </summary>
        private static int compareCardsOfGameDeck(Deck deck)
        {
            if (!checkIfCardsAreEqual(deck))
            {
                CardRank maxRank = deck.cards[0].Value;
                int maxIdx = 0;

                for (int i = 1; i < deck.cards.Count; i++)
                {
                    if (deck.cards[i].Value > maxRank)
                    {
                        maxRank = deck.cards[i].Value;
                        maxIdx = i;
                    }
                }
                return maxIdx;
            }

            else
                return -1;

        }

        /// <summary>
        /// chekc if all the cards drawn from players are having same value or not
        /// <param name="deck">game deck on which players draws their top card</param>
        /// <returns>True, if all the cards in deck are of same value, False otherwise</returns>
        /// </summary>
        private static bool checkIfCardsAreEqual(Deck deck)
        {
            return deck.cards.All(card => card.Value == deck.cards[0].Value);
        }
    }
}
