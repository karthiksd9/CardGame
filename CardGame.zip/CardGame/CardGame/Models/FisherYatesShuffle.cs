﻿// -----------------------------------------------------------------------------
// <copyright file="FisherYatesShuffle.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame.Models
{
    using System;
    using System.Collections.Generic;


    /// <summary>
    /// Based on Java code from wikipedia:
    /// http://en.wikipedia.org/wiki/Fisher-Yates_shuffle
    /// </summary>
    public static class FisherYatesShuffle
    {
        private static Random random = new Random();


        /// <summary> Shuffle the items in the collection </summary>
        public static void Shuffle<T>(this IList<T> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = random.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}
