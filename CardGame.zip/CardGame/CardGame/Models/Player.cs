﻿// -----------------------------------------------------------------------------
// <copyright file="Player.cs" company="Karthik SD">
// Copyright (c) Karthik SD. All rights reserved.
// </copyright>
// -----------------------------------------------------------------------------

namespace CardGame.Models
{
    using System;

    public class Player
    {
        /// <summary>
        /// name of the player
        /// </summary>
        public string name;
        
        /// <summary>
        /// deck of player from which he draws during game
        /// </summary>
        /// 
        public Deck drawPile;

        /// <summary>
        /// deck of player which holds the cards he won in game
        /// </summary>
        public Deck discardPile;

        /// <summary>
        /// initializes the player object
        /// </summary>
        public Player(string playerName)
        {
            name = playerName;
            drawPile = new Deck(0);
            discardPile = new Deck(0);
        }

        /// <summary>
        /// gets the total cards available with player
        /// <returns>count of cards</returns>
        /// </summary>
        public int getPlayerTotalCardsCount()
        {
            return drawPile.getCardCount() + discardPile.getCardCount();
        }

        /// <summary>
        /// if the draw pile if a player is empty,
        /// then fill the darw pile with the cards from discard pile.
        /// if discard pile is also empty, print the empty message
        /// </summary>
        public void fillDrawPileFromDiscard()
        {
            if(drawPile.isEmpty())
            {
                discardPile.ShuffleDeck();
                drawPile = Helper.Clone(discardPile);
                discardPile.removeAllFromDeck();
            }
            else
            {
                Console.WriteLine("Player draw pile is not empty!");
            }
        }
    }
}
